Write a function `countOccurences` that takes a string as argument, and returns an object. This object will associate the number of occurences of a word with an array of corresponding words.


Here are a few test cases:

Test:   countOccurences("hello is it you hello hello")
Return:
```{ '1': [ 'is', 'it', 'you' ], '3': [ 'hello' ] }
```

Test:   countOccurences("hey mama hey mama")
Return:
```{ '2': [ 'hey', 'mama' ] }
```
