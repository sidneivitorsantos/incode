Write a function `pyramid` that takes the size of the base as argument, and draws a pyramid of `#`.

Test:   pyramid(9)
Output:
```    #
   ###
  #####
 #######
#########
```

Test: pyramid(1)
Output:
```#
```

Test: pyramid(5)
```  #
 ###
#####
```
