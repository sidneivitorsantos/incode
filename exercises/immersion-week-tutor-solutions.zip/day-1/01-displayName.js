function displayName(name, surname) {
    console.log("My name is " + surname + ", " + name + " " + surname)
}

displayName("James", "Bond");
displayName("Ada", "Lovelace");