function concatArray(words) {
    console.log(words.join(" ") + ".")
}

concatArray(["Hello", "this", "is", "dog"])
concatArray(["All", "I", "want", "for", "christmas", "is", "you"])
concatArray([])