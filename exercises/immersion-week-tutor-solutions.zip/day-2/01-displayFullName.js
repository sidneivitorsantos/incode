function displayFullName(name) {
    const arrayName = name.split(" ")
    console.log("My name is " + arrayName[arrayName.length - 1] + ", " + name)
}

displayFullName("James Bond")
displayFullName("Ada Lovelace")
displayFullName("Salvador Felipe Jacinto Dalí")