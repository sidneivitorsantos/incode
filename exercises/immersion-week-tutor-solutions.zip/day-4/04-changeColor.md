Write a file `changeColor.js` to be included in the `change_color.html` file joined to the mission.

Like the h3 tag on the page says, you will make it that whenever the mouse hovers over a color name, the square takes the corresponding color.

## Example

[/gif]