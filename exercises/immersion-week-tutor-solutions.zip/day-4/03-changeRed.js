"use strict";

document.addEventListener("DOMContentLoaded", function() {

    document.getElementById("square").addEventListener("mouseover", function(event) {
        event.target.style.backgroundColor = "red"
    });

});